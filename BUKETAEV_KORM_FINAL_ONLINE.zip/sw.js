const CACHE_NAME='buketaev-korm-final-online-v1';
const ASSETS=['./','./index.html','./manifest.json','./icon.svg'];
self.addEventListener('install', e=>{ e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())); });
self.addEventListener('activate', e=>{ e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', e=>{
  if(e.request.method!=='GET') return;
  e.respondWith(caches.match(e.request).then(r=>r || fetch(e.request).then(resp=>{
    const copy = resp.clone(); caches.open(CACHE_NAME).then(c=>c.put(e.request, copy)).catch(()=>{});
    return resp;
  }).catch(()=>caches.match('./index.html'))));
});